import 'package:flutter/material.dart';

class StyledTextWidget extends StatelessWidget {
  const StyledTextWidget(this.text, this.textColor, this.fontSize, {super.key});

  final String text;
  final Color textColor;
  final double? fontSize;

  @override
  Widget build(BuildContext context) {
    return Text(text,
      style: TextStyle(
        color: textColor,
        fontSize: fontSize,
      ),
    );
  }
}
